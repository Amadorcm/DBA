import jade.core.Agent;
import java.util.Iterator;

public class BasicHelloWorld extends Agent{
    @Override
    protected void setup(){
        System.out.println("Hola soy el primer Agente");
        System.out.println("My local name is: "+ getAID().getLocalName());
        System.out.println("My GUID id: "+ getAID().getName());
        System.out.println("My addresses are:");
        Iterator it=getAID().getAllAddresses();
        while(it.hasNext()){
            System.out.println("- "+ it.next());
        }
        doDelete();
    }
    @Override
    public void takeDown(){
        System.out.println("Teminating Agent ... :)");
    }
};