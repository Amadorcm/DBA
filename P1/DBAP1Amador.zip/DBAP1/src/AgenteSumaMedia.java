import jade.core.Agent;
import jade.core.behaviours.OneShotBehaviour;
import java.util.Scanner;
public class AgenteSumaMedia extends Agent {
    private int numeroElementos = 0;
    private int suma = 0;
    @Override
    protected void setup() {
        System.out.println("Agente " + getAID().getName());
        addBehaviour(new SolicitarNumeroElementos());
        addBehaviour(new LeerElementos());
        addBehaviour(new Calcular());
    }

    private class SolicitarNumeroElementos extends OneShotBehaviour {
        @Override
        public void action() {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Ingrese el número de elementos: ");
            numeroElementos = scanner.nextInt();
        }
    }

    private class LeerElementos extends OneShotBehaviour{
        private int elementosLeidos = 0;

        @Override
        public void action() {
            Scanner scanner = new Scanner(System.in);
            int elemento = 0;
            for(int i=0; i<numeroElementos; i++){
                System.out.print("Ingrese el elemento " + (elementosLeidos + 1) + ": ");
                elemento = scanner.nextInt();
                suma += elemento;
                elementosLeidos++;
            }

        }


    }

    private class Calcular extends OneShotBehaviour {
        @Override
        public void action() {
            // Calcula la media y muestra los resultados.
            double media = (double) suma / numeroElementos;
            System.out.println("Suma: " + suma);
            System.out.println("Media: " + media);
            doDelete();
        }
    }
    @Override
    public void takeDown() {
        System.out.println("Terminating Agent: " + getAID().getName());
    }
}


/*
public class AgenteSumaMedia extends Agent {
    private double suma = 0;
    private int elementosLeidos = 0;

    @Override
    protected void setup() {
        System.out.println("Agente: " + getAID().getName());
        addBehaviour(new Calcular());
    }

    private class Calcular extends Behaviour {

        @Override
        public void action() {
            System.out.println("Por favor, introduzca un elemento numérico (o ingrese 'fin' para terminar):");
            Scanner scanner = new Scanner(System.in);
            String entrada = scanner.nextLine();

            if (entrada.equalsIgnoreCase("fin")) {
                double media = suma / elementosLeidos;
                System.out.println("La suma es: " + suma);
                System.out.println("La media es: " + media);
                myAgent.doDelete(); // Terminar el agente
            } else {
                try {
                    double elemento = Double.parseDouble(entrada);
                    suma += elemento;
                    elementosLeidos++;
                } catch (NumberFormatException e) {
                    System.out.println("Entrada no válida. Introduzca un número o 'fin' para terminar.");
                }
            }
        }

        @Override
        public boolean done() {
            return false; // El agente no termina hasta que se ingrese 'fin'
        }
    }

    @Override
    public void takeDown() {
        System.out.println("Terminating Agent: " + getAID().getName());
    }
}
*/