import jade.core.Agent;
import jade.core.behaviours.TickerBehaviour;
import java.util.Iterator;

public class TickerAgent extends Agent{
    @Override
    protected  void setup(){
        System.out.println("Agente: " + getAID().getName());
        addBehaviour(new MensajePeriodico(this,2000));
    }
    class MensajePeriodico extends TickerBehaviour{

        MensajePeriodico(Agent A,long n){
            super(A,n);
        }
        @Override
        public void onTick(){
            System.out.println("Agente imprimiendo mensaje periodico cada 2s de forma indefinida");
        }
    }
    @Override
    public void takeDown(){
        System.out.println("Teminating Agent: " + getAID().getName());
    }
}
