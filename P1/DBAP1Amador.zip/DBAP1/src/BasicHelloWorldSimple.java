import jade.core.Agent;
public class BasicHelloWorldSimple extends Agent{
    @Override
    protected void setup(){
        System.out.println("Hola soy el primer Agente");

    }

};